// A) STM8 -> WS2812B (STM8S208, 16MHz internal RC)
// test driver for WS2812B using SPI (MOSI used as data ouput on PC6, SCK left unconnected)
// Possible release MISO using BIDIrectional mode

#include "stm8s.h"
#include "milis.h"
#include "swspi.h"
//#include "stdio.h"
//#include "spse_stm8.h"
//#include "stm8_hd44780.h"

// 	Pins & others
void init(void);
//  RGB ring
void init_spi(void);
void test(uint8_t* data, uint16_t delka);
//  MAX7219
void max7219_init(void);
void zobraz(void);

// test pattern for (12 RGB LED ring)
uint8_t colors[36]={
0x20,0x00,0x00,	// RED
0x00,0x20,0x00,	// GREEN	
0x00,0x00,0x20,	// BLUE
};
uint16_t last_time = 0;

#define L_PATTERN 0b01110000 // 3x125ns (8MHZ SPI)
#define H_PATTERN 0b01111100 // 5x125ns (8MHZ SPI), first and last bit must be zero (to remain MOSI in Low between frames/bits)
#define DECODEMODE        (0x9<<8)
#define INTENSITY         (0xa<<8)
#define SCANLIMIT         (0xb<<8)
#define SHUTDOWN          (0xc<<8)
#define DTEST             (0xf<<8)

#define ZNAK1             (0x1<<8)
#define ZNAK2             (0x2<<8)
#define ZNAK3             (0x3<<8)
#define ZNAK4             (0x4<<8)
#define ZNAK5             (0x5<<8)
#define ZNAK6             (0x6<<8)
#define ZNAK7             (0x7<<8)
#define ZNAK8             (0x8<<8)

void main(void){
	init();

	while (1){
		zobraz();
		
		if (milis() - last_time >= 2){
			last_time = milis();
			test(colors,sizeof(colors)); 	// transfer image into RGB LED string
		}
	}
}

void init(){
	CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); 						// 16MHz from internal RC
	init_milis();
	init_spi();
	max7219_init();
	swspi_init();
}

//---------------------------------------------------------- RGB ring
// takes array of LED_number * 3 bytes (RGB per LED)
void test(uint8_t* data, uint16_t length){
	uint8_t mask;
	disableInterrupts(); 																			// can be omitted if interrupts do not take more then about ~25us
	while(length){   																					// for all bytes from input array
		length--;
		mask=0b10000000; 																				// for all bits in byte
		while(mask){
			while(!(SPI->SR & SPI_SR_TXE)); 											// wait for empty SPI buffer
			if(mask & data[length]){ 															// send pulse with coresponding length ("L" od "H")
				SPI->DR = H_PATTERN;
			}else{
				SPI->DR = L_PATTERN;
			}
			mask = mask >> 1;
		}
	}
	enableInterrupts();
	while(SPI->SR & SPI_SR_BSY);	 														// wait until end of transfer - there should come "reset" (>50us in Low)
}

void init_spi(void){
// Software slave managment (disable CS/SS input), BiDirectional-Mode release MISO pin to general purpose
SPI->CR2 |= SPI_CR2_SSM | SPI_CR2_SSI | SPI_CR2_BDM | SPI_CR2_BDOE; 
SPI->CR1 |= SPI_CR1_SPE | SPI_CR1_MSTR; // Enable SPI as master at maximum speed (F_MCU/2, there 16/2=8MHz)
}

//---------------------------------------------------------- MAX7912
void zobraz(void){
		swspi_tx16(ZNAK1 | 0);
		swspi_tx16(ZNAK2 | 0);
		swspi_tx16(ZNAK3 | 1);
		swspi_tx16(ZNAK4 | 0);
		
		swspi_tx16(ZNAK5 | 1);
		swspi_tx16(ZNAK6 | 1);
		swspi_tx16(ZNAK7 | 1);
		swspi_tx16(ZNAK8 | 0);
}

void max7219_init(void){
	swspi_tx16(DECODEMODE | 0xff);
	swspi_tx16(INTENSITY  | 0);
	swspi_tx16(SCANLIMIT  | 7);
	swspi_tx16(DTEST      | 0);
	swspi_tx16(SHUTDOWN   | 1);

}


// pod t�mto koment��em nic nem��te 
#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */                                                
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */                               
  while (1)
  {
  }
}
#endif